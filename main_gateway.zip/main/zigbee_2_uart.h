

#ifndef cJSON_H
#define cJSON_H

#include "nuos_data_structs.h"
#ifdef __cplusplus
extern "C" {
#endif
    extern void uart_init(void);
    void send_uart_command_in_array(node_module_t *node, const char *cmd);
    // void send_module_addc_over_uart(int room_id,
    //                                 const node_module_t *module,
    //                                 int start_idx);
    extern void send_module_unconfigured_over_uart(esp_zb_ieee_addr_t ieee_addr);

    void send_module_ctrl_over_uart(
                                    uint8_t room_id,
                                    uint8_t module_id, 
                                    uint8_t ep_id,
                                    uint8_t val,
                                    int start_idx,
                                    esp_zb_ieee_addr_t ieee_addr); 
                                    
                                    
    int uart_putc(uint8_t byte);    
    int uart_put_all(uint8_t *byte, uint8_t len); 
#ifdef __cplusplus
    }
#endif                      
#endif // cJSON_H
