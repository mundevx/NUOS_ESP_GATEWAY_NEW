

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_log.h"
#include "cJSON.h"
#include "esp_zigbee_type.h"
#include "nuos_nvs.h"
#include "cJSON.h"
#include "esp_zigbee_core.h"
#include "driver/uart.h"
#include "common.h"

#include "esp_timer.h"
#include "esp_log.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mbedtls/base64.h"
#include "mbedtls/aes.h"


#include "XBee.h"



void decrypt_single_block(const char* base64_encrypted);
char* Fn_DECRYPT_DATA(const char* V_RECEIVED_DATA_STR);
char* Fn_ENCRYPT_DATA(const char* V_RECEIVED_DATA_STR);
// handle of the timer
static esp_timer_handle_t periodic_timer;

#define LIGHT_BULB_DEVICE_PARAMS_TAG 	                        "LIGHT_BULB_DEVICE_PARAMS"


static const char *TAG = "ESP_ZB_TO_UART";



#define UART_PORT_NUM                                           UART_NUM_1
#define UART_TX_PIN                                             5
#define UART_RX_PIN                                             4
#define UART_BAUD_RATE                                          115200
#define UART_BUF_SIZE                                           (1024)




extern uint16_t devices_count;
extern node_module_t device_array[MAX_DEVICES];

uint16_t scene_short_addr = 0;
uint8_t scene_ep = 0;

void stop_timer_10s(void);
void start_timer_10s(void);
static int counter =0;

//void send_module_unconfigured_over_uart();


XBee xbee                                                                       = XBee();
ZBRxResponse rx                                                                 = ZBRxResponse();
ZBTxStatusResponse txStatus                                                     = ZBTxStatusResponse();
AtCommandResponse atResponse                                                    = AtCommandResponse();
RemoteAtCommandResponse remoteAtResponse                                        = RemoteAtCommandResponse();
Rx16Response rx16                                                               = Rx16Response();

// const char* V_SEND_ENCRYPTED_DATA_TO_MODULE_STR = "tx 1 ";
#define XBEE_ADDR_H             0x0013A200
#define XBEE_ADDR_L             0x421B379C

uint32_t V_ROUTER_ADDR_H_HEX = XBEE_ADDR_H, V_ROUTER_ADDR_L_HEX = XBEE_ADDR_L;



// Encryption key (first 16 bytes, ignore the null terminator)
static const unsigned char C_ENCRYPTION_KEY_2[16] = {
    0x66, 0x61, 0x6c, 0x63, 0x6f, 0x6e, 0x4c, 0x44,
    0x41, 0x43, 0x4f, 0x44, 0x45, 0x2d, 0x2a, 0x2d
    // Note: Original had 17 bytes with null terminator, but AES needs 16 bytes
};
//7e 00 27 10 04 00 13 a2 00 42 1b 37 9c ff fe 00 00 73 70 4e 46 6b 73 71 34 5a 6f 44 59 77 64 56 47 2f 77 39 44 43 77 3d 3d 00 da
uint64_t V_RECEIVED_DATA_MODULE_ADDR_H_HEX = 0;
uint64_t V_RECEIVED_DATA_MODULE_ADDR_L_HEX = 0;
const char* V_RECEIVED_DATA_FROM_MODULE_ENCRYPTED_STR = "";
const char* V_RECEIVED_DATA_FROM_MODULE_STR = "";
bool F_DECRYPTION_FROM_MODULE_ENABLE = false;
void find_and_execute_ctrl_command(uint8_t room_id, uint8_t module_id, int* didx, int *val, bool isArray);

#ifdef __cplusplus
extern "C" {
#endif
extern void nuos_zb_leave_device(uint16_t module_id, uint16_t did);
#ifdef __cplusplus
}
#endif

void send_xbee_data_over_uart(const char* V_SEND_ENCRYPTED_DATA_TO_MODULE_STR, uint16_t len, esp_zb_ieee_addr_t ieee_addr);
bool Fn_ENCRYPT_DATA_TO_BUFFER(const char* plaintext_data, char* output_buffer, size_t buffer_size) ;


// Helper function to convert esp_zb_ieee_addr_t to XBeeAddress64
void convert_zigbee_to_xbee_addr(const esp_zb_ieee_addr_t zigbee_addr, 
                                 uint32_t* msb, uint32_t* lsb) {
    // Convert big-endian 8-byte array to two 32-bit integers
    *msb = (zigbee_addr[0] << 24) | (zigbee_addr[1] << 16) | 
           (zigbee_addr[2] << 8) | zigbee_addr[3];
    
    *lsb = (zigbee_addr[4] << 24) | (zigbee_addr[5] << 16) | 
           (zigbee_addr[6] << 8) | zigbee_addr[7];
}

static void build_ctrl_string(
                              uint8_t room_id,
                                uint8_t module_id, 
                                uint8_t ep_id,
                                uint8_t val,
                              int start_idx,
                              char *out,
                              size_t out_size)
{
    int len = 0;
    if (start_idx == 0) {
        // Full array form
        len = snprintf(out, out_size, "ctrl/%d*%u@0,[", room_id, module_id);

        // for (int i = 0; i < MAX_DEVICES_IN_MODULE; i++) {
        //     int val;
        //     if (i < module->ep_counts) {
        //         // real endpoint present
        //         val = module->endpoint[i].ep;   // adjust field as needed
        //     } else {
        //         // empty slot
        //         val = -255;
        //     }

        //     len += snprintf(out + len, out_size - len,
        //                     (i == MAX_DEVICES_IN_MODULE - 1) ? "%d" : "%d,",
        //                     val);
        // }

        snprintf(out + len, out_size - len, "]!");
    } else {
        // Single endpoint form: "addc/room_id*module_id@idx,255!"
        // clamp index into 1..MAX_DEVICES_IN_MODULE
        if (start_idx < 1) start_idx = 1;
        if (start_idx > MAX_DEVICES_IN_MODULE) start_idx = MAX_DEVICES_IN_MODULE;

        snprintf(out, out_size, "ctrl/%d*%u@%d,%d!",
                 room_id, module_id, ep_id, val);
    }
}

extern "C" void send_module_unconfigured_over_uart(esp_zb_ieee_addr_t ieee_addr)
{
    //char tx_buf[128];  // enough for your format
    //build_addc_string(room_id, module, start_idx, tx_buf, sizeof(tx_buf));
    //const char* unconfigured_str = "cntr/255*255@0,[-255,-255,-255,-255,-255,-255]!";
    const char* unconfigured_str = "cntr/255*255@0,-255!";
    printf(unconfigured_str);
    vTaskDelay(pdMS_TO_TICKS(100));
    //uart_write_bytes(UART_PORT_NUM, unconfigured_str, strlen(unconfigured_str));   // send string
    send_xbee_data_over_uart(unconfigured_str, strlen(unconfigured_str), ieee_addr);
    //uart_write_bytes(UART_PORT_NUM, "\n", 1);                  // optional newline
    //start_timer_10s();
}
//const char* send_device_str = "addc/1*1@0,[1,2,3,4,-255,-255]!";

extern "C" void send_module_ctrl_over_uart(
                                uint8_t room_id,
                                uint8_t module_id, 
                                uint8_t ep_id,
                                uint8_t val,
                                int start_idx,
                                esp_zb_ieee_addr_t ieee_addr)
{
    char tx_buf[128];  // enough for your format
    build_ctrl_string(room_id, module_id, ep_id, val, 1, tx_buf, sizeof(tx_buf));

    printf("==========>UART TX: %s  len:%d\n", tx_buf, strlen(tx_buf));

    send_xbee_data_over_uart(tx_buf, strlen(tx_buf), ieee_addr);
    //uart_write_bytes(UART_PORT_NUM, tx_buf, strlen(tx_buf));   // send string
    //uart_write_bytes(UART_PORT_NUM, "\n", 1);                // optional new line
}


extern "C" int uart_putc(uint8_t byte) {
    return uart_write_bytes(UART_PORT_NUM, (const char*)&byte, 1);
}

extern "C" int uart_put_all(uint8_t *byte, uint8_t len) {
    printf("\nSending encrypted data to Gateway: \n");
    for(int i = 0; i < len; i++) {
        printf(" %02x", byte[i]);
    }
    printf("\n");
    
    uart_write_bytes(UART_PORT_NUM, (const char*)byte, len);
    return uart_write_bytes(UART_PORT_NUM, "\n", 1); 
}

uint8_t frameId = 0;
void send_xbee_data_over_uart(const char* mdata, uint16_t len, esp_zb_ieee_addr_t ieee_addr)
{

    const char* V_SEND_ENCRYPTED_DATA_TO_MODULE_STR = Fn_ENCRYPT_DATA(mdata);
    
    if (V_SEND_ENCRYPTED_DATA_TO_MODULE_STR) {
        printf("\nEncrypted result: %s\n\n", V_SEND_ENCRYPTED_DATA_TO_MODULE_STR);
    }
    int max_data_len = strlen(V_SEND_ENCRYPTED_DATA_TO_MODULE_STR) + 1;
    char V_SEND_DATA_TO_MODULE_CHAR[max_data_len];

    //char V_SEND_DATA_TO_MODULE_CHAR[len + 1];
    memset(V_SEND_DATA_TO_MODULE_CHAR, 0, sizeof(V_SEND_DATA_TO_MODULE_CHAR));
    // //data.toCharArray(V_SEND_DATA_TO_MODULE_CHAR, len + 1);
    strncpy(V_SEND_DATA_TO_MODULE_CHAR, V_SEND_ENCRYPTED_DATA_TO_MODULE_STR, max_data_len);
    
    // V_SEND_DATA_TO_MODULE_CHAR = (const uint8_t*)data;
    // copying the transmit to coordinator char array into wireless communication payload
    uint8_t payload[max_data_len];
    memset(payload, 0, sizeof(payload));
    
    uint8_t V_IDX_PAYLOAD_ARR;
    
    for(V_IDX_PAYLOAD_ARR = 0; V_IDX_PAYLOAD_ARR < strlen(V_SEND_ENCRYPTED_DATA_TO_MODULE_STR); V_IDX_PAYLOAD_ARR++)
    {
        payload[V_IDX_PAYLOAD_ARR] = V_SEND_DATA_TO_MODULE_CHAR[V_IDX_PAYLOAD_ARR]-0;
        // LogInfo(payload[V_IDX_PAYLOAD_ARR]);
    }
  
    // Usage
    convert_zigbee_to_xbee_addr(ieee_addr, &V_ROUTER_ADDR_H_HEX, &V_ROUTER_ADDR_L_HEX);

    printf("V_ROUTER_ADDR_H_HEX: %04lx", V_ROUTER_ADDR_H_HEX);
    printf("  V_ROUTER_ADDR_L_HEX: %04lx\n", V_ROUTER_ADDR_L_HEX);

    V_ROUTER_ADDR_H_HEX = XBEE_ADDR_H;
    V_ROUTER_ADDR_L_HEX = XBEE_ADDR_L;

    // check if we get a return of 0 router address or room and module ids are out of valid range
    if(V_ROUTER_ADDR_H_HEX != 0 && V_ROUTER_ADDR_L_HEX != 0) // zigbee module
    {
        // make a new packet and send it to module
        // XBeeAddress64 addr64 = XBeeAddress64(V_ROUTER_ADDR_H_HEX, V_ROUTER_ADDR_L_HEX);
        // ZBTxRequest zbTx = ZBTxRequest(addr64, payload, sizeof(payload));
        // //ZBRxResponse zbTx = ZBRxResponse();
        // // sending payload over wireless communication
        // uint8_t V_XbeeMsmgNextFrameId = xbee.getNextFrameId();
        // zbTx.setFrameId(V_XbeeMsmgNextFrameId);
        // xbee.send(zbTx);


        // Create ZB Transmit Request
        ZBTxRequest txRequest;
        XBeeAddress64 addr64 = XBeeAddress64(V_ROUTER_ADDR_H_HEX, V_ROUTER_ADDR_L_HEX);
        // Set the destination address
        txRequest.setAddress64(addr64);
        
        // Set broadcast address (0xFFFE means unknown 16-bit address)
        txRequest.setAddress16(0xFFFE);
    
    // Set frame ID (0 = no response expected, 1-255 = expect status response)
    //if(frameId == 0) {
    uint8_t frameId = xbee.getNextFrameId(); // Auto-incrementing frame ID
    //}
    txRequest.setFrameId(frameId);
    
    // Set the payload
    txRequest.setPayload(payload, sizeof(payload));
    
    // Optionally set transmission options
    txRequest.setOption(0); // 0 = unicast, 1 = broadcast
    txRequest.setApiId(ZB_TX_STATUS_RESPONSE);  //added
    // Send the request
    xbee.send(txRequest);        
    } else {
        // LogError("Router address is 0 or room/module id out of range");
        printf("Router address is 0 or room/module id out of range\n");
    }
}

void convert_xbee_to_esp_zigbee_addr_memcpy(const XBeeAddress64 &xbee_addr , esp_zb_ieee_addr_t zigbee_addr) {
    XBeeAddress64& non_const_xbee = const_cast<XBeeAddress64&>(xbee_addr);
    uint32_t msb = non_const_xbee.getMsb();
    uint32_t lsb = non_const_xbee.getLsb();
    
    // Create temporary 32-bit variables in network byte order
    uint32_t msb_be = __builtin_bswap32(msb);  // Convert to big-endian if needed
    uint32_t lsb_be = __builtin_bswap32(lsb);
    
    // Copy to output array
    memcpy(&zigbee_addr[0], &msb_be, 4);
    memcpy(&zigbee_addr[4], &lsb_be, 4);
    
    printf("Converted XBee to Zigbee (memcpy): ");
    for (int i = 0; i < 8; i++) {
        printf("%02x", zigbee_addr[i]);
    }
    printf("\n");
}

void uart_receiver_task(void *arg) {
    uint8_t data[UART_BUF_SIZE] = {0};
    
    counter = 0;
    while(1) {
        // Read ONE byte at a time to feed into XBee parser
        int len = uart_read_bytes(UART_PORT_NUM, data, sizeof(data), 100 / portTICK_PERIOD_MS);
        if(len > 1) {
            data[len] = '\0'; // Null-terminate safely 
            // Echo back received data
            printf("\n\nReceived encrypted data from Gateway: \n");
            for(int i = 0; i < len; i++) {
                // Process each byte
                printf(" %02X", data[i]);
            }
            printf("\n");
            
            // Store byte in XBee's buffer
            memcpy(xbee.serial_read_data, (const uint8_t*)data, len);
            xbee.serial_read_data[len] = '\0'; // Null terminate for single byte
            xbee.serial_read_data_counter = 0;
            xbee.serial_data_available = true;
        
            // Process the byte through XBee parser
            xbee.readPacket();
            // Check if we have a complete response
            if(xbee.getResponse().isAvailable()) {
                printf("XBee Response Available. API ID: 0x%02X\n", xbee.getResponse().getApiId());
                if(xbee.getResponse().getApiId() == ZB_TX_REQUEST) {
                    ZBRxResponse rx;
                    xbee.getResponse().getZBRxResponse(rx);

                    if (rx.getOption() == ZB_PACKET_ACKNOWLEDGED) {
                        // the sender got an ACK
                        printf("packet acknowledged\n");
                    } else {
                        printf("packet not acknowledged\n");
                    }
                    printf("checksum is ");
                    printf("0x%02x\n", rx.getChecksum());
                    printf("Rx_len: %d\n", rx.getDataLength()-2);
                    // Process received data
                    char received_data[rx.getDataLength()-2 + 1];
                    for(int i = 0; i < rx.getDataLength()-2; i++) {
                        received_data[i] = rx.getData(2+i);
                        printf(" %02x", received_data[i]);
                    }
                    printf("\n");

                    received_data[rx.getDataLength()-2] = '\0';

                    static char encrypted_buffer[512]; // Static buffer for simplicity
                    if (Fn_ENCRYPT_DATA_TO_BUFFER(Fn_DECRYPT_DATA(received_data), encrypted_buffer, sizeof(encrypted_buffer))) {
                        printf( "encrypted_buffer:%s\n", encrypted_buffer);

// XBeeAddress64 testAddr(0x13A200, 0x421B379C);
// uint32_t testMsb = testAddr.getMsb();
// uint32_t testLsb = testAddr.getLsb();
// printf("Test Address: MSB = 0x%08lX, LSB = 0x%08lX\n", testMsb, testLsb);


                        XBeeAddress64 addr = rx.getRemoteAddress64();
                        uint32_t msb = addr.getMsb();
                        uint32_t lsb = addr.getLsb();
                        printf("Remote Address: MSB = %08lX, LSB = %08lX\n", msb, lsb);

                        esp_zb_ieee_addr_t zigbee_addr = {0x00, 0x13, 0xa2, 0x00, 0x42, 0x1b, 0x37, 0x9c};
                        //convert_xbee_to_esp_zigbee_addr_memcpy(rx.getRemoteAddress64(), zigbee_addr);
                        send_xbee_data_over_uart(received_data, strlen(received_data), zigbee_addr);
                        //send_module_unconfigured_over_uart(zigbee_addr);
                    }
//zb_rx  0x90
                }
            } else {
                printf("No complete XBee response available yet.\n");
            }
           
        }
        vTaskDelay(10 / portTICK_PERIOD_MS);
        // if(counter++ >= 600){
        //     counter = 0;
        //     send_module_unconfigured_over_uart(rx.getRemoteAddress64().getAddress());
        //     printf("UART Receiver Task is running...\n");
        // }
    }
}


typedef struct CtrlCommand_s {
  char command[20];      // "ctrl", "addc", "removec"
  uint8_t roomId;      // 1
  uint8_t moduleId;    // 1
  uint8_t deviceId;    // 1 or 0
  int8_t value;        // 0-255 or array of 6 values [-255..255]
  bool isArray;        // false for single, true for array
  int16_t values[6];    // for array mode
}CtrlCommand;

CtrlCommand parseCtrlMsg(const char* msg) {
    CtrlCommand cmd = { {0}, 0, 0, 0, 0, false, {0} };
    
    // Extract command (before first /)
    char temp[128];
    strncpy(temp, msg, sizeof(temp) - 1);
    temp[sizeof(temp) - 1] = '\0';
    
    char* token = strtok(temp, "/");
    if (token) {
        strncpy(cmd.command, token, sizeof(cmd.command) - 1);
        cmd.command[sizeof(cmd.command) - 1] = '\0';
    }
    
    // Extract room/module/device (split by *)
    token = strtok(NULL, "*");
    if (token) cmd.roomId = (uint8_t)atoi(token);
    
    token = strtok(NULL, "@");
    if (token) cmd.moduleId = (uint8_t)atoi(token);
    
    token = strtok(NULL, ",[!");
    if (token) cmd.deviceId = (uint8_t)atoi(token);
    
    // Check if array or single value
    char* next = strstr(msg, "[");
    if (next) {
        cmd.isArray = true;
        // Parse array [0,0,0,0,-255,-255]
        char* arrayStart = strchr(msg, '[');
        if (arrayStart) {
            arrayStart++; // skip [
            for (int i = 0; i < 6; i++) {
                // Skip whitespace/numbers
                while (*arrayStart && (*arrayStart < '0' || *arrayStart > '9') && *arrayStart != '-' && *arrayStart != '+') {
                    arrayStart++;
                }
                if (!*arrayStart) break;
                
                cmd.values[i] = (int8_t)atoi(arrayStart);
                arrayStart = strchr(arrayStart, ',');
                if (arrayStart) {
                    arrayStart++;
                } else {
                    break;
                }
            }
        }
    } else {
        cmd.isArray = false;
        // Single value before !
        char* valStart = strstr(msg, ",");
        if (valStart) {
            valStart++; // skip ,
            // Skip to number
            while (*valStart && (*valStart < '0' || *valStart > '9') && *valStart != '-' && *valStart != '+') {
                valStart++;
            }
            cmd.value = (int8_t)atoi(valStart);
        }
    }
    
    return cmd;
}


void process_uart_data(const uint8_t* data, uint16_t len){

    int didx[6] = {0};
    int value[6] = {0};

    CtrlCommand cmd = parseCtrlMsg((char*)data);
    
    // // Debug output
    printf("Cmd:  %s ", cmd.command);
    printf(" Room: %d", cmd.roomId);
    printf(" Mod: %d", cmd.moduleId);
    printf(" Dev:%d\n", cmd.deviceId);

    // Forward parsed data 
    if(cmd.command[0] == 'a' && cmd.command[1] == 'd' && cmd.command[2] == 'd' && cmd.command[3] == 'd'){
        printf("Sending response back to gateway : %s\n" , (char*)data);
        //send_serial((char*)data);
        //send_xbee_data_over_uart((char*)data, strlen((char*)data), ieee_addr);
        stop_timer_10s();
    } else if(cmd.command[0] == 'a' && cmd.command[1] == 'd' && cmd.command[2] == 'd' && cmd.command[3] == 'c'){
        printf("Sending response back to gateway : %s\n" , (char*)data);
        //send_serial((char*)data, ieee_addr);
        stop_timer_10s();

        uint8_t nindex = 255;
        for(int i=0; i<devices_count; i++){
            if(device_array[i].module_id == 0 || device_array[i].module_id == 255){
                nindex = i;
                break;
            }
        }
        if(nindex == 255){
            return;
        }
        printf("After save to NVS devices_count:%d  nindex:%d\n", devices_count, nindex);

        device_array[nindex].module_id = cmd.moduleId;
        device_array[nindex].room_id = cmd.roomId;
        //node_module_t * module = find_device_by_room_module_id(cmd.roomId, cmd.moduleId);

        if(save_or_update_light_bulb_device_to_nvs(&device_array[nindex]) == ESP_OK){
    		//read_device_info();
    		memset(device_array, 0, sizeof(device_array));
    		devices_count = 0;
    		read_all_devices_from_nvs(NULL);
    	}
    // delc/1*1@0,-255!
    } else if(cmd.command[0] == 'd' && cmd.command[1] == 'e' && cmd.command[2] == 'l' && cmd.command[3] == 'c'){
        //send_serial((char*)data, ieee_addr);
        node_module_t * module_remove = find_device_by_node(cmd.moduleId, cmd.deviceId);

        if(module_remove != NULL){

            nuos_zb_leave_device(cmd.moduleId, cmd.deviceId);

        }
    } else if(cmd.command[0] == 'c' && cmd.command[1] == 't' && cmd.command[2] == 'r' && cmd.command[3] == 'l'){
        //send_serial((char*)data, ieee_addr);
        
        printf("Found ctrl Command!!\n");
        if(cmd.deviceId == 0){
            // Array mode
            didx[0] = 1;
            value[0] = cmd.values[0];
            value[1] = cmd.values[1];
            value[2] = cmd.values[2];
            value[3] = cmd.values[3];
            value[4] = cmd.values[4];
            value[5] = cmd.values[5];
        } else {
            // Single value mode
            didx[0] = cmd.deviceId;
            value[0] = cmd.value;
        }
        printf("roomId:%d   moduleId:%d   deviceId:%d\n", cmd.roomId, cmd.moduleId, didx[0]);
        find_and_execute_ctrl_command(cmd.roomId, cmd.moduleId, didx, value, cmd.isArray);
    }

}




void find_and_execute_ctrl_command(uint8_t room_id, uint8_t module_id, int* didx, int *val, bool isArray) {
    uint8_t total_counts = 0;
    uint8_t level = 0;
    uint8_t nodeindex=0, epindex=0;
    uint16_t node_type = 0;
    uint16_t color = 0;

    node_module_t * module = find_device_by_room_module_id(room_id, module_id);
    //node_module_t * module = find_device_by_node(cmd.moduleId, didx[0]);

    if(module != NULL){

        if (didx[0] == 0) {
            // Array mode - process cmd.values[]
            // For simplicity, just use the first value for now
            for(int j=0; j<module->ep_counts;j++){
                didx[j] = module->endpoint[j].ep;
            }
            
            total_counts = module->ep_counts;
            //val_key_not_found_flag = false;
        } else {
            // Single value mode
            level = val[0];
            total_counts = 1;

        }
        for(int i = 0; i < total_counts; i++){
            uint8_t did = didx[i];
            if (didx[i] > 0 && didx[i] != -255) {
                if (find_device_by_dev_id(module_id, did, &nodeindex, &epindex)) {
                    printf("find_device_by_dev_id success!!\n");

                    if (node_type == 0) {
                        node_type = find_device_type(nodeindex, epindex);
                    }
                    if (didx[i] == 0) {
                        level = val[i];
                    }else{
                        level = val[0];
                    }
                    printf("nodeindex:%d, level:%d epindex:%d \n", nodeindex, level, epindex);
                    switch (node_type) {
                        case 4:
                        case 0:
                            if (get_total_endpoints(nodeindex) <= 2) {
                                nuos_update_curtain_cluster(nodeindex, epindex, level);
                            } else {
                                printf("Scene pressed!!\n");
                            }
                            break;
                        case 256:
                        case 257:
                            if (level == 0 || level == 255) {
                                nuos_update_onoff_cluster(nodeindex, epindex, level ? true : false);
                            } else {
                                nuos_update_level_cluster(nodeindex, epindex, level);
                            }
                            break;
                        case 269:
                            if (color > 0) {
                                nuos_update_color_hue(nodeindex, epindex, color);
                            } else {
                                if (level == 0 || level == 255) {
                                    nuos_update_onoff_cluster(nodeindex, epindex, level ? true : false);
                                } else {
                                    nuos_update_level_cluster(nodeindex, epindex, level);
                                }
                            }
                            break;
                        case 268:  // color temperature
                            if (color > 0) {
                                nuos_update_color_temperature(nodeindex, epindex, color);
                            } else {
                                if (level == 0 || level == 255) {
                                    nuos_update_onoff_cluster(nodeindex, epindex, level ? true : false);
                                } else {
                                    nuos_update_level_cluster(nodeindex, epindex, level);
                                }
                            }
                            break;
                        case 769:
                            {
                                bool is_fan = is_fan_control(nodeindex, epindex);
                                if (is_fan) {
                                    zigbee_cluster_fan_control_attr_update(nodeindex, epindex, level);
                                } else {
                                    zigbee_cluster_thermostat_attr_update(nodeindex, epindex, level);
                                }
                            }
                            break;
                        default:
                            break;
                    }
                } else {
                    printf("did not found!!\n");
                }
            }
        }
    } else {
        printf("Device not found for ctrl command!!\n");
    }

}


static portMUX_TYPE uart_mutex = portMUX_INITIALIZER_UNLOCKED;

const uart_config_t uart_config = {
    .baud_rate = 115200,
    .data_bits = UART_DATA_8_BITS,
    .parity    = UART_PARITY_DISABLE,
    .stop_bits = UART_STOP_BITS_1,
    .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
    .source_clk = UART_SCLK_XTAL, // or UART_SCLK_APB if preferred
};

extern "C" void uart_init(void)
{

    // 1) configure params
    esp_err_t err = uart_param_config(UART_PORT_NUM, &uart_config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "uart_param_config failed: %d", err);
        return;
    }

    // 2) set pins
    err = uart_set_pin(UART_PORT_NUM, UART_TX_PIN, UART_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "uart_set_pin failed: %d", err);
        return;
    }

    // 3) install driver
    err = uart_driver_install(UART_PORT_NUM, UART_BUF_SIZE, UART_BUF_SIZE, 0, NULL, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "uart_driver_install failed: %d", err);
        return;
    }
    // optional: small delay while bringing hardware up (for debugging only)
    vTaskDelay(pdMS_TO_TICKS(50));
    xTaskCreate(uart_receiver_task, "uart_receiver_task", 4096, NULL, 20, NULL);
    //send_serial("NUOS Zigbee Gateway!!");
    vTaskDelay(pdMS_TO_TICKS(50));
}    


// void send_serial(const char* data){

//     printf("==========>UART TX: %s  len:%d\n", data, strlen(data));

//     send_xbee_data_over_uart(data, strlen(data), esp_zb_get_coordinator_ieee_addr());

//     // int len = uart_write_bytes(UART_PORT_NUM, data, strlen(data));
//     // if (len < 0) {
//     //     ESP_LOGE(TAG, "uart_write_bytes failed: %d", len);
//     // } else {
//     //     // Wait until all bytes are pushed out of hardware FIFO (optional)
//     //     // Convert ms to ticks: ticks = pdMS_TO_TICKS(timeout_ms)
//     //     uart_wait_tx_done(UART_PORT_NUM, pdMS_TO_TICKS(100));
//     // }

//     // len = uart_write_bytes(UART_PORT_NUM, "\n", 1);
//     // if (len < 0) {
//     //     ESP_LOGE(TAG, "uart_write_bytes failed: %d", len);
//     // } else {
//     //     // Wait until all bytes are pushed out of hardware FIFO (optional)
//     //     // Convert ms to ticks: ticks = pdMS_TO_TICKS(timeout_ms)
//     //     uart_wait_tx_done(UART_PORT_NUM, pdMS_TO_TICKS(100));
//     // } 
// }


void send_uart_command(node_module_t *node, uint8_t ep_index, const char *cmd, uint8_t val) {

}


void send_uart_command_in_array(node_module_t *node, const char *cmd){

}



void extract_ctrl_m_did(const char *json_str, uint16_t scene_short, uint8_t scene_ep) {
    
}


/**
 * @brief Timer callback function (runs every 10 seconds)
 */
static void timer_callback(void *arg)
{
    //send_module_unconfigured_over_uart();
    ESP_LOGI(TAG, "Timer fired!");
}

/**
 * @brief Start a periodic timer with 10 seconds interval
 */

void start_timer_10s(void)
{
    if (periodic_timer != NULL) {
        ESP_LOGW(TAG, "Timer already running!");
        return;
    }
    const esp_timer_create_args_t timer_args = {
        .callback = &timer_callback,
        .arg = NULL,
        .dispatch_method = ESP_TIMER_TASK,
        .name = "my_10s_timer"
    };
    // Create timer
    ESP_ERROR_CHECK(esp_timer_create(&timer_args, &periodic_timer));
    // Start periodic timer: 10 sec = 10,000,000 microseconds
    ESP_ERROR_CHECK(esp_timer_start_periodic(periodic_timer, 10 * 1000 * 1000));
    ESP_LOGI(TAG, "10-second periodic timer started ...");
}

/**
 * @brief Stop and delete the periodic timer
 */
void stop_timer_10s(void)
{
    if (periodic_timer == NULL) {
        ESP_LOGW(TAG, "Timer not running!");
        return;
    }
    ESP_ERROR_CHECK(esp_timer_stop(periodic_timer));
    ESP_ERROR_CHECK(esp_timer_delete(periodic_timer));
    periodic_timer = NULL;
    ESP_LOGI(TAG, "10-second periodic timer stopped");
}


void decrypt_single_block(const char* base64_encrypted) {
    const char* encrypted_data = "0o97i80zJiNQHtJls/gJoA==";
    
    printf("Encrypted string: %s\n", encrypted_data);
    printf("Length: %zu\n", strlen(encrypted_data));
    
    // Base64 decode
    unsigned char decoded[16];
    size_t decoded_len;
    
    int ret = mbedtls_base64_decode(decoded, sizeof(decoded), &decoded_len,
                                   (const unsigned char*)encrypted_data, 
                                   strlen(encrypted_data));
    
    if (ret != 0) {
        printf("Base64 decode failed: %d\n", ret);
        return;
    }
    
    printf("Decoded bytes (%zu): ", decoded_len);
    for (size_t i = 0; i < decoded_len; i++) {
        printf("%02x ", decoded[i]);
    }
    printf("\n");
    
    // AES decrypt
    mbedtls_aes_context aes;
    mbedtls_aes_init(&aes);
    mbedtls_aes_setkey_dec(&aes, C_ENCRYPTION_KEY_2, 128);
    
    unsigned char decrypted[16];
    mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_DECRYPT, decoded, decrypted);
    
    mbedtls_aes_free(&aes);
    
    printf("Decrypted bytes: ");
    for (int i = 0; i < 16; i++) {
        printf("%02x ", decrypted[i]);
    }
    printf("\n");
    
    // Try to interpret as string
    decrypted[15] = '\0'; // Null terminate
    printf("As string: %s\n", (char*)decrypted);
    
    // Also print as characters
    printf("As characters: ");
    for (int i = 0; i < 16; i++) {
        if (decrypted[i] >= 32 && decrypted[i] <= 126) {
            printf("%c", decrypted[i]);
        } else {
            printf(".");
        }
    }
    printf("\n");
}


/**
 * @brief Decrypts AES-encrypted base64 data
 * @param V_RECEIVED_DATA_STR Base64 encoded encrypted string
 * @return Decrypted string (caller must free) or NULL on failure
 */
char* Fn_DECRYPT_DATA(const char* V_RECEIVED_DATA_STR) {
    // Constants
    const uint8_t C_ENCRYPT_DECRYPT_WORD_LENGTH = 16;
    const uint8_t C_WORD_BASE64_LENGTH = 24;
    
    printf("Decrypting data: ");
    printf(" %s\n", V_RECEIVED_DATA_STR);
    
    // Get input length
    size_t V_DATA_TO_DECRYPT_BUFFER_BYTE_LENGTH = strlen(V_RECEIVED_DATA_STR);
    //printf("Data to decrypt length: %zu\n", V_DATA_TO_DECRYPT_BUFFER_BYTE_LENGTH);
    
    // Check if input length is valid (must be multiple of 24)
    if (V_DATA_TO_DECRYPT_BUFFER_BYTE_LENGTH % C_WORD_BASE64_LENGTH != 0) {
        printf("Error: Input length %zu is not multiple of %d\n", 
               V_DATA_TO_DECRYPT_BUFFER_BYTE_LENGTH, C_WORD_BASE64_LENGTH);
        return NULL;
    }
    
    // Compute number of 24-character base64 blocks
    uint16_t V_NO_OF_WORDS_BASE64_IN_RESULT_INT = V_DATA_TO_DECRYPT_BUFFER_BYTE_LENGTH / C_WORD_BASE64_LENGTH;
    //printf("Number of blocks to process: %u\n", V_NO_OF_WORDS_BASE64_IN_RESULT_INT);
    
    // Allocate buffer for concatenated decrypted data
    size_t total_decrypted_size = V_NO_OF_WORDS_BASE64_IN_RESULT_INT * C_ENCRYPT_DECRYPT_WORD_LENGTH + 1;
    char* V_DECRYPTED_DATA_WITH_LENGTH_STR = (char*)calloc(total_decrypted_size, sizeof(char));
    if (!V_DECRYPTED_DATA_WITH_LENGTH_STR) {
        printf("Failed to allocate memory for decrypted data\n");
        return NULL;
    }
    
    // Initialize AES context
    mbedtls_aes_context aes;
    mbedtls_aes_init(&aes);
    mbedtls_aes_setkey_dec(&aes, C_ENCRYPTION_KEY_2, 128);
    
    size_t total_decrypted_len = 0;
    
    // Process each 24-character base64 block
    for (uint8_t V_IDX_DATA_TO_DECRYPT_WORD = 0; 
         V_IDX_DATA_TO_DECRYPT_WORD < V_NO_OF_WORDS_BASE64_IN_RESULT_INT; 
         V_IDX_DATA_TO_DECRYPT_WORD++) {
        
        // Extract 24-character base64 block
        char V_ENCRYPTED_DATA_WORD_BASE64[C_WORD_BASE64_LENGTH + 1];
        memcpy(V_ENCRYPTED_DATA_WORD_BASE64, 
               V_RECEIVED_DATA_STR + (V_IDX_DATA_TO_DECRYPT_WORD * C_WORD_BASE64_LENGTH), 
               C_WORD_BASE64_LENGTH);
        V_ENCRYPTED_DATA_WORD_BASE64[C_WORD_BASE64_LENGTH] = '\0';
        
        //printf("Block %d base64: %s\n", V_IDX_DATA_TO_DECRYPT_WORD, V_ENCRYPTED_DATA_WORD_BASE64);
        
        // Base64 decode
        unsigned char V_ENCRYPTED_DATA_WORD_DECODED[C_ENCRYPT_DECRYPT_WORD_LENGTH];
        size_t decoded_len;
        
        int ret = mbedtls_base64_decode(V_ENCRYPTED_DATA_WORD_DECODED, 
                                        sizeof(V_ENCRYPTED_DATA_WORD_DECODED),
                                        &decoded_len,
                                        (const unsigned char*)V_ENCRYPTED_DATA_WORD_BASE64,
                                        C_WORD_BASE64_LENGTH);
        
        if (ret != 0 || decoded_len != C_ENCRYPT_DECRYPT_WORD_LENGTH) {
            printf("Base64 decode failed: %d (expected 16 bytes, got %zu)\n", ret, decoded_len);
            mbedtls_aes_free(&aes);
            free(V_DECRYPTED_DATA_WITH_LENGTH_STR);
            return NULL;
        }
        
        // Decrypt the block (ECB mode)
        unsigned char V_DECRYPTED_DATA_WORD[C_ENCRYPT_DECRYPT_WORD_LENGTH];
        mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_DECRYPT, 
                              V_ENCRYPTED_DATA_WORD_DECODED, 
                              V_DECRYPTED_DATA_WORD);
        
        // Append to result string
        memcpy(V_DECRYPTED_DATA_WITH_LENGTH_STR + total_decrypted_len,
               V_DECRYPTED_DATA_WORD,
               C_ENCRYPT_DECRYPT_WORD_LENGTH);
        
        total_decrypted_len += C_ENCRYPT_DECRYPT_WORD_LENGTH;
        
        // printf("Block %d decrypted: ", V_IDX_DATA_TO_DECRYPT_WORD);
        // for (int i = 0; i < C_ENCRYPT_DECRYPT_WORD_LENGTH; i++) {
        //     printf("%c", V_DECRYPTED_DATA_WORD[i] >= 32 ? V_DECRYPTED_DATA_WORD[i] : '.');
        // }
        // printf("\n");
    }
    
    mbedtls_aes_free(&aes);
    
    // Null terminate the concatenated string
    V_DECRYPTED_DATA_WITH_LENGTH_STR[total_decrypted_len] = '\0';
    
    //printf("Full decrypted with length prefix: %s\n", V_DECRYPTED_DATA_WITH_LENGTH_STR);
    
    // Find '(' to separate length from data
    char* paren_ptr = strchr(V_DECRYPTED_DATA_WITH_LENGTH_STR, '(');
    if (!paren_ptr) {
        printf("Error: No '(' found in decrypted data\n");
        free(V_DECRYPTED_DATA_WITH_LENGTH_STR);
        return NULL;
    }
    
    // Extract length (everything before '(')
    size_t length_str_len = paren_ptr - V_DECRYPTED_DATA_WITH_LENGTH_STR;
    if (length_str_len == 0 || length_str_len > 10) { // Reasonable length check
        printf("Error: Invalid length string\n");
        free(V_DECRYPTED_DATA_WITH_LENGTH_STR);
        return NULL;
    }
    
    // Create null-terminated length string
    char length_str[11] = {0};
    strncpy(length_str, V_DECRYPTED_DATA_WITH_LENGTH_STR, length_str_len);
    length_str[length_str_len] = '\0';
    
    //printf("Length string: %s\n", length_str);
    
    // Convert length to integer
    uint16_t V_DECRYPTED_DATA_LENGTH_INT = atoi(length_str);
    //printf("Data length: %u\n", V_DECRYPTED_DATA_LENGTH_INT);
    
    // Calculate where data starts (after '(')
    char* data_start = paren_ptr + 1;
    
    // Check if we have enough data
    size_t data_available = strlen(data_start);
    if (V_DECRYPTED_DATA_LENGTH_INT > data_available) {
        printf("Error: Data length %u exceeds available data %zu\n", 
               V_DECRYPTED_DATA_LENGTH_INT, data_available);
        free(V_DECRYPTED_DATA_WITH_LENGTH_STR);
        return NULL;
    }
    
    // Allocate final result buffer
    char* V_DECRYPTED_DATA_STR = (char*)malloc(V_DECRYPTED_DATA_LENGTH_INT + 1);
    if (!V_DECRYPTED_DATA_STR) {
        printf("Failed to allocate memory for final result\n");
        free(V_DECRYPTED_DATA_WITH_LENGTH_STR);
        return NULL;
    }
    
    // Copy only the specified length
    memcpy(V_DECRYPTED_DATA_STR, data_start, V_DECRYPTED_DATA_LENGTH_INT);
    V_DECRYPTED_DATA_STR[V_DECRYPTED_DATA_LENGTH_INT] = '\0';
    
    printf("Final decrypted data: %s\n", V_DECRYPTED_DATA_STR);
    //printf("Final length: %u\n", V_DECRYPTED_DATA_LENGTH_INT);
    
    // Free intermediate buffer
    free(V_DECRYPTED_DATA_WITH_LENGTH_STR);
    
    return V_DECRYPTED_DATA_STR;
}

/**
 * @brief Wrapper function for easier use with char arrays
 * @param encrypted_data Base64 encrypted data
 * @param decrypted_output Buffer to store decrypted data (must be pre-allocated)
 * @param output_size Size of output buffer
 * @return true on success, false on failure
 */
bool Fn_DECRYPT_DATA_TO_BUFFER(const char* encrypted_data, char* decrypted_output, size_t output_size) {
    char* decrypted = Fn_DECRYPT_DATA(encrypted_data);
    if (!decrypted) {
        return false;
    }
    
    size_t decrypted_len = strlen(decrypted);
    if (decrypted_len >= output_size) {
        free(decrypted);
        return false;
    }
    
    strcpy(decrypted_output, decrypted);
    free(decrypted);
    return true;
}

/**
 * @brief Helper function to free decrypted data
 * @param data Pointer to decrypted data returned by Fn_DECRYPT_DATA
 */
void free_decrypted_data(char* data) {
    if (data) {
        free(data);
    }
}
char* Fn_ENCRYPT_DATA(const char* V_RECEIVED_DATA_STR) {
    //printf("----------------------------\n");
    printf("Encrypting data : ");
    printf("%s\n", V_RECEIVED_DATA_STR);
    // Your data is 13 bytes: "ctrl/1*3@1,0!"
    // Create buffer: "13(ctrl/1*3@1,0!" = 16 bytes (no padding needed)
    
    unsigned char plaintext[16] = {
        '1', '3', '(', 
        'c', 't', 'r', 'l', '/', 
        '1', '*', '3', '@', 
        '1', ',', '0', '!'
    };
    
    // printf("Plaintext (hex): ");
    // for (int i = 0; i < 16; i++) {
    //     printf("%02x ", plaintext[i]);
    // }
    // printf("\n");
    
    // Encrypt
    mbedtls_aes_context aes;
    mbedtls_aes_init(&aes);
    mbedtls_aes_setkey_enc(&aes, C_ENCRYPTION_KEY_2, 128);
    
    unsigned char encrypted[16];
    mbedtls_aes_crypt_ecb(&aes, MBEDTLS_AES_ENCRYPT, plaintext, encrypted);
    
    mbedtls_aes_free(&aes);
    
    printf("Encrypted (hex): ");
    for (int i = 0; i < 16; i++) {
        printf("%02x ", encrypted[i]);
    }
    printf("\n");
    
    // Base64 encode
    // For 16 bytes, base64 requires 24 characters + null terminator
    char* base64_output = (char*)malloc(25); // 24 + 1
    if (!base64_output) {
        return NULL;
    }
    
    size_t base64_len;
    int ret = mbedtls_base64_encode((unsigned char*)base64_output, 25, &base64_len, encrypted, 16);
    
    if (ret != 0) {
        printf("Base64 encode error: %d\n", ret);
        free(base64_output);
        return NULL;
    }
    
    // Ensure null termination
    base64_output[base64_len] = '\0';
    
    //printf("Base64: %s (length: %zu)\n", base64_output, base64_len);
    
    return base64_output;
}


/**
 * @brief Wrapper function for easier use
 * @param plaintext_data Data to encrypt
 * @param output_buffer Buffer to store result (must be pre-allocated)
 * @param buffer_size Size of output buffer
 * @return true on success, false on failure
 */
bool Fn_ENCRYPT_DATA_TO_BUFFER(const char* plaintext_data, char* output_buffer, size_t buffer_size) {
    char* encrypted = Fn_ENCRYPT_DATA(plaintext_data);
    if (!encrypted) {
        return false;
    }
    
    size_t encrypted_len = strlen(encrypted);
    if (encrypted_len >= buffer_size) {
        free(encrypted);
        return false;
    }
    
    strcpy(output_buffer, encrypted);
    free(encrypted);
    return true;
}

/**
 * @brief Helper function to free encrypted data
 * @param data Pointer to encrypted data returned by Fn_ENCRYPT_DATA
 */
void free_encrypted_data(char* data) {
    if (data) {
        free(data);
    }
}

/*#define DEVICE_4R_ON_OFF_LIGHT 					                1
#define DEVICE_2R_ON_OFF_LIGHT 					                2
#define DEVICE_2T_ANALOG_DIMMABLE_LIGHT 			            3
#define DEVICE_1CH_CURTAIN 					                    4
#define DEVICE_2CH_CURTAIN 					                    5  //rarely used

#define DEVICE_1_LIGHT_1_FAN                                    6
#define DEVICE_1_LIGHT_1_FAN_CUSTOM                             7  //customized clusters for Tuya
#define DEVICE_IR_BLASTER                                       8
#define DEVICE_IR_BLASTER_CUSTOM                                9  //customized clusters for Tuya

#define DEVICE_WIRELESS_SCENE_SWITCH                            10

#define DEVICE_CCT_DALI_CUSTOM                                  11 //customized clusters for Tuya
#define DEVICE_RGB_DALI                                         12
#define DEVICE_RGB_DMX                                          13 
#define DEVICE_GROUP_DALI                                       14

#define DEVICE_RINGING_BELL     					            15
#define DEVICE_SENSOR_MOTION                                    16
#define DEVICE_SENSOR_CONTACT_SWITCH                            17
#define DEVICE_SENSOR_GAS_LEAK                                  18
#define DEVICE_SENSOR_TEMPERATURE_HUMIDITY                      19
#define DEVICE_SENSOR_LUX                                       20 //TSL2561


#define  CMD_ADD_DEVICE                                         1
#define  CMD_UPDATE_DEVICE                                      2
#define  CMD_DELETE_DEVICE                                      3
#define  CMD_OFFLINE_DEVICE                                     4
#define  CMD_START_COMMISSIONING                                5
#define  CMD_END_COMMISSIONING                                  6
#define  CMD_CTRL_DEVICE                                        7
#define  CMD_SET_SCENE                                          8
 */